const mongoose = require('mongoose');

const OrderItemSchema = new mongoose.Schema({
  productId: String,
  productName: String,
  size: String,
  quantity: Number,
  price: Number,
});

const OrderSchema = new mongoose.Schema({
  id: { type: String, required: true }, // gunakan uuid dari frontend
  tableNumber: String, // untuk in place
  customer: {
    id: String,
    name: String,
    address: String,
    coordinates: {
      lat: Number,
      lng: Number,
    },
  },
  items: [OrderItemSchema],
  deliOption: String, // 'in-place', 'delivery', 'pick-up'
  paymentMethod: String,
  totalPayment: Number,
  date: String,
  image: String,
  orderType: String, // 'IN_PLACE', 'DELIVER', 'PICK_UP'
  status: {
    type: String,
    enum: ['pending', 'processing', 'completed', 'cancelled'],
    default: 'pending'
  },
});

module.exports = mongoose.model('Order', OrderSchema);
