const express = require('express');
const router = express.Router();
const { createOrder, getOrders, getOrderById } = require('../controllers/orderController');

router.post('/', createOrder);   // POST /api/orders
router.get('/', getOrders);      // GET /api/orders
router.get('/:id', getOrderById); // GET /api/orders/:id

module.exports = router;
