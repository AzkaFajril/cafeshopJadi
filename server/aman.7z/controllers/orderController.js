const Order = require('../models/Order');

exports.createOrder = async (req, res) => {
  try {
    if (
      (req.body.deliOption === 'in-place' || req.body.orderType === 'IN_PLACE') &&
      (!req.body.tableNumber || req.body.tableNumber.trim() === '')
    ) {
      // Hanya warning, tetap lanjut
      console.warn('Order in-place tanpa nomor meja');
    }

    const order = new Order(req.body);
    await order.save();
    res.status(201).json({ success: true, order });
  } catch (err) {
    res.status(400).json({ success: false, message: err.message });
  }
};

exports.getOrders = async (req, res) => {
  try {
    const orders = await Order.find().sort({ date: -1 });
    res.json(orders);
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

exports.getOrderById = async (req, res) => {
  try {
    const order = await Order.findById(req.params.id);
    if (!order) return res.status(404).json({ success: false, message: 'Order not found' });
    // Mapping deliveryType dari orderType/deliOption
    let deliveryType = order.orderType || order.deliOption || '';
    // Jika ingin label lebih ramah user
    if (deliveryType === 'IN_PLACE' || deliveryType === 'in-place') deliveryType = 'in place';
    else if (deliveryType === 'DELIVER' || deliveryType === 'delivery') deliveryType = 'delivery';
    else if (deliveryType === 'PICK_UP' || deliveryType === 'pick-up') deliveryType = 'self pick-up';
    res.json({ ...order.toObject(), deliveryType });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};
