const Order = require('../models/Order');
const Product = require('../models/Product'); // pastikan sudah di-import

exports.createOrder = async (req, res) => {
  try {
    // Ambil items dari request
    const orderItems = req.body.items;

    // Tambahkan image ke setiap item
    const itemsWithImage = await Promise.all(
      orderItems.map(async (item) => {
        const product = await Product.findById(item.productId);
        return {
          ...item,
          image: product?.image || '', // ambil gambar dari DB
        };
      })
    );

    // Buat order baru dengan items yang sudah ada image
    const order = new Order({
      ...req.body,
      items: itemsWithImage,
    });

    await order.save();
    res.status(201).json({ success: true, order });
  } catch (err) {
    res.status(400).json({ success: false, message: err.message });
  }
};

exports.getOrders = async (req, res) => {
  try {
    const orders = await Order.find().sort({ date: -1 });
    res.json(orders);
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

exports.getOrderById = async (req, res) => {
  try {
    const order = await Order.findById(req.params.id);
    if (!order) return res.status(404).json({ success: false, message: 'Order not found' });
    // Mapping deliveryType dari orderType/deliOption
    let deliveryType = order.orderType || order.deliOption || '';
    // Jika ingin label lebih ramah user
    if (deliveryType === 'IN_PLACE' || deliveryType === 'in-place') deliveryType = 'in place';
    else if (deliveryType === 'DELIVER' || deliveryType === 'delivery') deliveryType = 'delivery';
    else if (deliveryType === 'PICK_UP' || deliveryType === 'pick-up') deliveryType = 'self pick-up';
    res.json({ ...order.toObject(), deliveryType });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

// Semua order
exports.getAllOrders = async (req, res) => {
  try {
    const orders = await Order.find();
    res.json(orders);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// Hanya in-place order (TAMBAHKAN INI)
exports.getInPlaceOrders = async (req, res) => {
  try {
    // Ganti 'orderType' atau 'deliOption' sesuai field di database kamu
    const orders = await Order.find({
      $or: [
        { orderType: 'IN_PLACE' },
        { deliOption: 'in-place' }
      ]
    });
    res.json(orders);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// Update status order
exports.updateOrderStatus = async (req, res) => {
  try {
    const { id } = req.params;
    const { status } = req.body;
    const order = await Order.findByIdAndUpdate(
      id,
      { status },
      { new: true }
    );
    if (!order) {
      return res.status(404).json({ error: 'Order not found' });
    }
    res.json(order);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};
